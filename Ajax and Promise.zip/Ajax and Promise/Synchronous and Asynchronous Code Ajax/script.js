//Synchronous Code
// const p = document.querySelector(".p");
// p.textContent = "My Name is Saif";
// alert("Text Set !");
// p.style.color = "red";

//Asynchronous Function
const p = document.querySelector("p");
setTimeout(function () {
  p.textContent = "My Name is Saif";
}, 5000);
p.style.color = "red";

//p.style.width = "1000px";
const img = document.querySelector(".image1");
img.src = "img/img-1.jpg";
img.addEventListener("load", function () {
  img.classList.add("fadeIn");
});
p.style.width = "300px";