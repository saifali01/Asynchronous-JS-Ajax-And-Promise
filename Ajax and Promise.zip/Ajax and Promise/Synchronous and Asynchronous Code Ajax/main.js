const p = document.querySelector(".p");
p.textContent = "My name is Jonas";
alert("Text Set ");
p.style.color = "red";
